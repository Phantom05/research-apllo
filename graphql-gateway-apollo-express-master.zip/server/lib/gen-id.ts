import uuid from 'uuid/v1';

const genId = () => uuid();

export default genId;
