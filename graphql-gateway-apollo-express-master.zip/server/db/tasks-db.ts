const tasks = [
  {
    id: '7e68efd1',
    name: 'Test task',
    completed: 0.0,
    createdAt: '2017-10-06T14:54:54+00:00',
    updatedAt: '2017-10-06T14:54:54+00:00',
    taskPriority: 1,
    progress: 55.5,
    state: 2,
  },
];

export default tasks;
