const globalSetup = async () => {
  console.info('seting up test'); // eslint-disable-line no-console
};

export default globalSetup;
