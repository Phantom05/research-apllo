describe('Example integration test suit', () => {
  it('integration test', () => {
    expect(true).toEqual(true);
  });
});
