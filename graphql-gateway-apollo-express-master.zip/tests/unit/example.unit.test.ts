
describe('Testing sql operations', () => {
  it('example test', () => {
    expect(true).toEqual(true);
  });
});
