const globalTeardown = async () => {
  console.info('tearing down test'); // eslint-disable-line no-console
};

export default globalTeardown;
